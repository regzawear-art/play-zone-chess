// KhelChess: Razorpay recurring subscriptions (monthly / yearly)
(function () {
  var FN_URL = 'https://mdcgdjurerwzbdshtirc.supabase.co/functions/v1/create-subscription';

  function loadCheckout() {
    return new Promise(function (resolve, reject) {
      if (window.Razorpay) return resolve();
      var s = document.createElement('script');
      s.src = 'https://checkout.razorpay.com/v1/checkout.js';
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error('Could not load Razorpay. Check your internet and try again.')); };
      document.head.appendChild(s);
    });
  }

  window.kcRzpSubscribe = async function (plan, sb) {
    if (plan.id !== 'monthly' && plan.id !== 'yearly') {
      throw new Error('This plan is not available for online purchase.');
    }
    var res = await sb.auth.getSession();
    var session = res && res.data && res.data.session;
    if (!session) throw new Error('Please log in to subscribe.');

    await loadCheckout();

    var headers = {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + session.access_token
    };
    if (sb.supabaseKey) headers.apikey = sb.supabaseKey;

    var r = await fetch(FN_URL, { method: 'POST', headers: headers, body: JSON.stringify({ plan: plan.id }) });
    var data = await r.json().catch(function () { return {}; });
    if (!r.ok || !data.subscription_id) {
      throw new Error(data.error || 'Could not start payment. Please try again.');
    }

    return new Promise(function (resolve, reject) {
      var rzp = new window.Razorpay({
        key: data.key_id,
        subscription_id: data.subscription_id,
        name: 'KhelChess',
        description: plan.name + ' Premium',
        prefill: { email: (session.user && session.user.email) || '' },
        notes: { plan: plan.id },
        theme: { color: '#2563eb' },
        handler: function () { resolve(); },
        modal: { ondismiss: function () { reject(new Error('Payment cancelled.')); } }
      });
      rzp.on('payment.failed', function (e) {
        reject(new Error((e && e.error && e.error.description) || 'Payment failed. Please try again.'));
      });
      rzp.open();
    });
  };
})();
